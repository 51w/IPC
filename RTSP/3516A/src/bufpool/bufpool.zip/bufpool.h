#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>

#define MinSize   1000*1024
#define MaxChnn   5
#define SizeVal   2000*1024
#define MaxNode   8

typedef struct
{
	char *bptr;
	int  len;
	int  timestamp;
	int	 naltype;
	int  datetype;	
}BPool;

typedef struct
{
	BPool datapool;
	int	  start_pos;
	int   end_pos;
}BufList;


//
int bufpool_put(BPool data);

int bufpool_get(BPool *data, int chn);

int bufpool_init(int size, int chn);

void bufpool_exit();


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif